#include "BPM.h"

// Constructor
BPM::BPM() : value(0) {}

BPM::BPM(int initialValue) : value(initialValue) {}

// Getter
int BPM::getValue() const {
    return value;
}

// Setter
void BPM::setValue(int newValue) {
    value = newValue;
}
