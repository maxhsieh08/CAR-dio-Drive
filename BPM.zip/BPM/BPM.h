#ifndef BPM_H
#define BPM_H

#include <Arduino.h>

class BPM {
private:
    int value;

public:
    // Constructor
    BPM();

    BPM(int initialValue);

    // Getter for value
    int getValue() const;

    // Setter for value
    void setValue(int newValue);
};

#endif // BPM_H
