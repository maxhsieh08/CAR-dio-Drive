#ifndef BPM_H
#define BPM_H

typedef struct bpm {
  int value;
} bpm;

#endif
