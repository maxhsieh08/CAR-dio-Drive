#ifndef EFFORT_H
#define EFFORT_H

typedef struct effort {
  double value;
} effort;

#endif
